
let dicasEl = [{
  nome: ["Marie Curie", "marie curie"],
  dicas: ['2. Fui prêmiada com o nobel da química pela descoberta de elementos químicos',
  '3. Tive uma morte estreitamente relacionada aos meus estudos',
  '4. Estudei na universidade de Sourbonne, na França',
  'Bônus: Juntamente com meu marido, desenvolvi estudos sobre a radioatividade'
]
}
]

let informacoesEl = "";

let botaoEl = document.querySelector('#botao');
let contadorMulheres = 0;
let contadorDicas = 0;
let perguntasEl = document.querySelector('#dicas');
let pontos = 5;

function exibePergunta () {
  let perguntasEl = document.querySelector('#dicas');
  let pergunta = document.createElement('h2');
  pergunta.innerHTML = `${dicasEl[contadorMulheres].dicas[contadorDicas]}`;
  perguntasEl.appendChild(pergunta);
  pergunta.classList.add('caixas');
  contadorDicas++;
  pontos--;
}

function finalizaPontua () {
  let estruturaEl = document.querySelector('#felicitacoes'); // A div na qual vai ser inserida a pontuacao
  let pontuacaoEl = document.createElement('h2');
  pontuacaoEl.innerHTML = `+${pontos} pontos`;
  estruturaEl.appendChild(pontuacaoEl);

}

botaoEl.addEventListener("click", exibePergunta);

function verificaResposta(){
  let inputEl = document.querySelector('#resposta');
  if(inputEl.value === dicasEl[contadorMulheres].nome[1] || inputEl.value === dicasEl[contadorMulheres].nome[0]){
    let perguntasEl = document.querySelector('#dicas');
    let acertoEl = document.createElement("img");
    let fimPontos = document.createElement('h3');
    fimPontos.innerHTML = `+${pontos} pontos`;
    acertoEl.src = "imgs/msg.png";
    perguntasEl.appendChild(acertoEl);
    perguntasEl.appendChild(fimPontos);
    contadorMulheres++;
    let conteudoEl = document.querySelector("#conteudo");
    let textoEl = document.createElement('p');
    textoEl.innerHTML = "";
    conteudoEl.appendChild(textoEl);
    let botaoProxEl = document.createElement("img");
    botaoProxEl.src= "imgs/bot2.png";
  //  conteudoEl.appendChild(botaoProxEl);
  }else{
    let perguntasEl = document.querySelector('#dicas');
    let erroEl = document.createElement("h3");
    erroEl.innerHTML = "Não sou eu :( Tente novamente!";
    perguntasEl.appendChild(erroEl);
  }
}

let caixaRespostaEl = document.querySelector("#resposta");
caixaRespostaEl.addEventListener("keyup", valida);

function valida(e) {
  let tecla = e.keyCode;
  if(tecla === 13){
    verificaResposta();
  }
}











// “Eu faço parte dos que pensam que a Ciência é belíssima. Um cientista em um laboratório não é apenas um técnico, ele é também uma criança diante de fenômenos naturais que o impressionam como um conto de fada. Não podemos acreditar que todo progresso científico se reduz a mecanismos, máquinas, engrenagens, mesmo que essas máquinas tenham sua própria beleza.”
