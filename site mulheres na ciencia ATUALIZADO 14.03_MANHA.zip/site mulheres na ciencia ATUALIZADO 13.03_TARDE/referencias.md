Referência: https://citacoes.in/autores/rosalind-franklin/
https://twitter.com/br/status/1102211551111598080 - imagem da Mary Kenneth Keller
https://stories.vassar.edu/2017/170706-legacy-of-grace-hopper.html - imagem grace hopper

Gnipper, P., 2016. Mulheres Históricas: Carol Shaw, A Primeira Desenvolvedora De Jogos Eletrônicos. [online] Canaltech. Available at: <https://canaltech.com.br/internet/mulheres-historicas-carol-shaw-a-primeira-desenvolvedora-de-jogos-eletronicos-75877/> [Accessed 14 March 2020].
https://www.gamespot.com/articles/a-look-back-at-trailblazing-game-developer-carol-s/1100-6457258/ - imagem da Carol Shaw
