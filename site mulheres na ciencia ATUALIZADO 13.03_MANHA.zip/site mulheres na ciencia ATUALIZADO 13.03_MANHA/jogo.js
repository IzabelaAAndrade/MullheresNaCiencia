
// VETOR DE OBJETOS COM AS MULHERES EM QUESTÃO
let dicasEl = [{
  nome: ["Marie Curie", "marie curie", "UM POUCO SOBRE MARIE CURIE"],
  dicas: ['1. Nasci na polônia, em 1867', '2. Fui prêmiada com o nobel da química pela descoberta de elementos químicos',
  '3. Tive uma morte estreitamente relacionada aos meus estudos',
  '4. Estudei na universidade de Sourbonne, na França',
  'Bônus: Juntamente com meu marido, desenvolvi estudos sobre a radioatividade'
  ],
  info: "Nascida em Varsóvia, na Polônia, Marie Curie foi uma cientista e física renomada, tendo descoberto o Polônio e o Rádio. Fez pesquisas importantíssimas sobre a radioatividade e por esse motivo foi a primeira mulher a ganhar o Prêmio Nobel e hoje é considerada a cientista mais conhecida da Terra. ",
}
]



let informacoesEl = "";

let botaoEl = document.querySelector('#botao'); // botão para adicionar nova dica
let contadorMulheres = 0;
let contadorDicas = 0;
let perguntasEl = document.querySelector('#dicas');
let pontos = 5;

// Função que coloca dicas na tela quando o botão é pressionado
function exibePergunta () {
  let perguntasEl = document.querySelector('#dicas');
  let pergunta = document.createElement('h2');
  pergunta.innerHTML = `${dicasEl[contadorMulheres].dicas[contadorDicas]}`;
  perguntasEl.appendChild(pergunta);
  pergunta.classList.add('caixas');
  contadorDicas++;
  pontos--;
}

// Apresenta a pontuação do jogador
function finalizaPontua () {
  let estruturaEl = document.querySelector('#felicitacoes'); // A div na qual vai ser inserida a pontuacao
  let pontuacaoEl = document.createElement('h2');
  pontuacaoEl.innerHTML = `+${pontos} pontos`;
  estruturaEl.appendChild(pontuacaoEl);

}

botaoEl.addEventListener("click", exibePergunta); // Exibe a dica quando o botão "dica" é apertado

// Função que verifica se a resosta dada no input está correta
function verificaResposta(){
  let inputEl = document.querySelector('#resposta');
  // Se a resposta estiver correta:
  if(inputEl.value === dicasEl[contadorMulheres].nome[1] || inputEl.value === dicasEl[contadorMulheres].nome[0]){
    let perguntasEl = document.querySelector('#dicas');
    let acertoEl = document.createElement("img");
    let fimPontos = document.createElement('h2');
    let conteudoEl = document.querySelector("#conteudo");
    let textoEl = document.createElement('p');
     //Mostrar mensagem de "Parabéns" pelo acerto
    fimPontos.innerHTML = `+${pontos} pontos`;
    acertoEl.src = "imgs/msg.png";
    acertoEl.classList.add("parabens");
    conteudoEl.appendChild(acertoEl);
    conteudoEl.appendChild(fimPontos);
    // Mostrar informações sobre a mulher em questão, para fins educativos
    let tituloRespostaEl = document.createElement("h5"); // criar o título
    tituloRespostaEl.innerHTML = `${dicasEl[contadorMulheres].nome[2]}`;
    conteudoEl.appendChild(tituloRespostaEl);
    textoEl.innerHTML = `${dicasEl[contadorMulheres].info}`;
    textoEl.classList.add("formTexto");
    conteudoEl.appendChild(textoEl); // Mostrar o texto, conteúdo

    // Botão para próxima fase ou próxima mulher
    let botaoProxEl = document.createElement("img");
    botaoProxEl.classList.add("bProx");
    botaoProxEl.src= "imgs/bot2.png";
    conteudoEl.appendChild(botaoProxEl);
    // Passa para a proxima mulher
    contadorMulheres++;
    let outrosPontos = pontos;

  }else{
    // Se a resposta estiver errada:
    let perguntasEl = document.querySelector('#dicas');
    let erroEl = document.createElement("h2");
    erroEl.innerHTML = "Não sou eu :( Tente novamente!"; //Mostrar mensagem de erro
    perguntasEl.appendChild(erroEl);
  }
}

let caixaRespostaEl = document.querySelector("#resposta");
caixaRespostaEl.addEventListener("keyup", valida);

//ativa a função para verificar a resposta ao se apertar a tecla "Enter"
function valida(e) {
  let tecla = e.keyCode;
  if(tecla === 13){
    verificaResposta();
  }
}


let proximaFaseBtnEl = document.querySelector('.bProx');
// proximaFaseBtnEl.addEventListener("click", ) começar denovo!









// “Eu faço parte dos que pensam que a Ciência é belíssima. Um cientista em um laboratório não é apenas um técnico, ele é também uma criança diante de fenômenos naturais que o impressionam como um conto de fada. Não podemos acreditar que todo progresso científico se reduz a mecanismos, máquinas, engrenagens, mesmo que essas máquinas tenham sua própria beleza.”
