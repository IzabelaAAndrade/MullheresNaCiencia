
let marieEl = document.querySelector("#log1");

function apareceIcone (){
  marieEl.classList.toggle('disa1');
}

setTimeout(apareceIcone(), 10000);
