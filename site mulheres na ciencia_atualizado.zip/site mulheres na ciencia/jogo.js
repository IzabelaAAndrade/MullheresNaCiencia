let dicasEl = ["2. Fui prêmiada com o nobel da química pela descoberta de elementos químicos",
"3. Tive uma morte estreitamente relacionada aos meus estudos",
"4. Estudei na universidade de Sourbonne, na França",
"Bônus: Juntamente com meu marido, desenvolvi estudos sobre a radioatividade"
]

let botaoEl = document.querySelector('#botao');
let contador = 0;
let perguntasEl = document.querySelector('#dicas');
let pontos = 5;

function exibePergunta () {
  let perguntasEl = document.querySelector('#dicas');
  let pergunta = document.createElement('h2');
  pergunta.innerHTML = `${dicasEl[contador]}`;
  perguntasEl.appendChild(pergunta);
  pergunta.classList.add('caixas');
  contador++;
  pontos--;
}

botaoEl.addEventListener("click", exibePergunta);

function verificaResposta(){
  let inputEl = document.querySelector('#resposta');
  if(inputEl.value === "Marie Curie" || inputEl.value === "marie curie"){
    window.open()
  }else{
    // erro - mostrar dicas ate a ultima
  }
}
// “Eu faço parte dos que pensam que a Ciência é belíssima. Um cientista em um laboratório não é apenas um técnico, ele é também uma criança diante de fenômenos naturais que o impressionam como um conto de fada. Não podemos acreditar que todo progresso científico se reduz a mecanismos, máquinas, engrenagens, mesmo que essas máquinas tenham sua própria beleza.”
