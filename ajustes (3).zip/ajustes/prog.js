let videos = ['imgs/gracehoper.mp4', 'imgs/video.mp4', 'imgs/video.mp4', 'imgs/video.mp4', 'imgs/video.mp4'];
let pastasEl = document.querySelectorAll(".pastas");
let btnVoltarEl = document.querySelector("#fechavid");
let vid = document.querySelector("#ovideo");
let obj =[{
		pastinhas: pastasEl[0],
		link: "vids/graceh.mp4"
},
{
	pastinhas: pastasEl[1],
	link: "vids/carols.mp4"
},
{
	pastinhas: pastasEl[2],
	link: "vids/maryk.mp4"
},
{
	pastinhas: pastasEl[3],
	link: "vids/vidMarg.mp4"
},

{
	pastinhas: pastasEl[4],
	link: "vids/adal.mp4"
}]



function abreVid(e) {
	let clicadoEl = e.currentTarget
	let j;
	let vid = document.querySelector("#ovideo");
	for(j=0; j<obj.length; j++){
		if(clicadoEl == obj[j].pastinhas){
			vid.src = obj[j].link;
		}
	}
	
	btnVoltarEl.classList.toggle("manipulavid");
	vid.classList.toggle('manipulavid');
}

for(let i=0; i<pastasEl.length; i++){
	pastasEl[i].addEventListener("click", abreVid);

}


function fechaVid (){
	let vid= document.querySelector("#ovideo");
	btnVoltarEl.classList.toggle("manipulavid");
	vid.classList.toggle('manipulavid');
	vid.pause();
}

btnVoltarEl.addEventListener("click", fechaVid);

let horaEl = document.querySelector("#horas");
let minutosEl = document.querySelector("#minutos");
let data = new Date();

horaEl.innerHTML = data.getHours();
let minutinhosEl = data.getMinutes()
if(minutinhosEl<10){
	minutosEl.innerHTML = `0${data.getMinutes()}`;
}else{
	minutosEl.innerHTML = data.getMinutes();
}
