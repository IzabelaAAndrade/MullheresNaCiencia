
// Vetor de objetos que contém as mulheres retratadas no jogo e suas respectivas informações

let dicasEl = [{
  nome: "Marie Curie",
  dicas: ['1. Nasci na polônia, em 1867', '2. Fui prêmiada com o Nobel da química pela descoberta de elementos químicos',
  '3. Tive uma morte estreitamente relacionada aos meus estudos',
  '4. Estudei na universidade de Sourbonne, na França',
  'Bônus: Juntamente com meu marido, desenvolvi estudos sobre a radioatividade'
  ],
  info: "Nascida em Varsóvia, na Polônia, Marie Curie foi uma cientista e física renomada, tendo descoberto o Polônio e o Rádio. Fez pesquisas importantíssimas sobre a radioatividade e por esse motivo foi a primeira mulher a ganhar o Prêmio Nobel e hoje é considerada a cientista mais conhecida da Terra. ",
  link: "https://267557-830227-raikfcquaxqncofqfm.stackpathdns.com/wp-content/uploads/2019/01/quem-foi-marie-curie-667x400.jpg",
},

{
  nome: "Carol Shaw",
  dicas: ['1. Cresci na costa Oeste dos EUA, proxima ao tecnopolo do vale do silício', '2. Tenho graduação em engenharia elétrica e ciências da computação',
  '3. Fui a primeira mulher a desenvolver um jogo eletrônico',
  '4. Desenvolvi os jogos Tic-Tac-Toe e o famoso "River Raid" ',
  'Bônus: Trabalhei para a Atari, para a Tandem Computers e para a  Activision'
  ],
  info: "A americana crescida nos arredores do vale do silício, Carol Shaw foi pioneira no mercado de desenvolvimento de games. Como engenheira de software, trabalhou no desenvolvimento de diversos jogos, dentre eles o 3-D Tic-Tac-Toe e o famoso River Raid",
  link: "https://i.imgur.com/KNcGG.jpg",
},

{
  nome: "Ada Lovelace",
  dicas: ['1. Vivi no século XIX', '2. Fui tutelada por Augustus De Morgan',
  '3.Trabalhei no desenvolvimento da máquina analítica com Charles Babbage',
  '4. Fui a primeira pessoa da história a desenvolver um algoritmo, programa de computador',
  'Bônus: Me desenvolvi muito na área de lógica e matemática'
  ],
  info: "A Condessa de Lovelace foi uma matemática e escritora inglesa. Escreveu o primeiro algoritmo a ser processado por uma máquina: a máquina analítica de Charles Babbage, sendo assim considerada a primeira programadora de todos os tempos.",
  link: "https://imagens.canaltech.com.br/146005.257839-Ada-Lovelace.jpg",
},

{
  nome: "Rosalind Franklin",
  dicas: ['1. Nasci 1920, em londres', '2. Fui pioneira na área de biologia molecular',
  '3. Estudei em Cambridge, onde conquistei um doutorado em química',
  '4. Descobri qual era a estrutura do DNA',
  'Bônus: Desenvolvi importantes materiais sobre as microestruturas do carvão e do grafite'
  ],
  info: "Foi uma química britânica que descobriu a dupla hélice do DNA, assim como a estrutura molecular do carvão e do grafite. ",
  link: "https://london.ac.uk/sites/default/files/styles/promo_mobile/public/2018-01/rosalind-franklin.png?itok=3JmBRIuf",
},

{
  nome: "Barbara McClintock",
  dicas: ['1. Sou uma das pessoas mais importantes que já estiveram no meio da genética', '2. Na faculdade estudei botânica, e através dela, a genética',
  '3. Muito trabalhei na análise cromossômica do milho',
  '4. Descobri os genes saltadores, responsáveis pelo fenômeno de transposição genética',
  'Bônus: '
  ],
  info: "Nascida nos EUA, Barbara foi uma citogeneticista responsável pela descoberta dos elementos genéticos que causam a transposição genética, além de ter demonstrado o conceito da recombinação genética por crossing-over. ",
  link: "https://images.ctfassets.net/eqlypemzu8y5/6TJhnszT1UALq1G9WZIoGf/03ecb6411e2145c7783ab4c1c26da178/Barbara_McClintock.jpg",
},

{
  nome: "Lise Meitner",
  dicas: ['1. Nasci na Áustria, em 1878', '2. Obtive doutorado em física na Universidade de Viena',
  '3. Trabalhei com o químico Otto Hahn, que posteriormente foi premiado com o Nobel da química pelo nosso trabalho',
  '4. Fiz cálculos e pesquisas diversas e pude explicar o processo de fissão nuclear',
  'Bônus: Recebi o prêmio Enrico Fermi junto a Hahn e Fritz Straßmann '
  ],
  info: "Lise foi uma física austríaca que fez a descoberta da fissão nuclear. Meitner também descobriu, em 1923, o efeito Auger, um fenômeno em que a emissão de um elétron de um átomo causa a emissão de um segundo elétron.",
  link: "https://aventurasnahistoria.uol.com.br/media/_versions/lise_meitner_widexl.jpg",
},

{
  nome: "Katherine Johnson",
  dicas: ['1. Nasci nos EUA e, aos dez anos de idade já estava no ensino médio', '2. Me formei em 1937 com exelência nas matérias de matemática e francês',
  '3. Trabalhei com cálculos na área computacional e aeroespacial da NASA, calculando a trajetória da missão Apollo 11',
  '4.  Recebi a medalha presidencial da Liberdade e tive minha história retratada no longa "Estrelas Além do Tempo".',
  'Bônus: Morri no início de janeiro de 2020'
  ],
  info: "Foi matemática, física e cientista espacial estadunidense. Contribuiu significativamente para a aeronáutica, principalmente nas aplicações de computação da NASA: ela calculava trajetórias, janelas de lançamento e caminhos de retorno emergencial para vários voos de missões.",
  link: "https://abrilsuperinteressante.files.wordpress.com/2018/08/katherine-johnson_fb.png",
},

{
  nome: "Chien-Shiung Wu",
  dicas: ['1. Sou Física, especialista em radioatividade, apelidadada de "Marie Curie Chinesa"', '2. Fui a primeira mulher a ter um doutorado honorado em física na universidade de princeton',
  '3. Meus experimentos desmnentiram a lei da Paridade, da mecânica quântica',
  '4. Ganhei diversos prêmios como: a Medalha John Price Wetherill do Instituto Franklin (1962) e o prêmio Wolf em Física (1978)  ',
  'Bônus: Trabalhei no projeto Manhattan .'
  ],
  info: " Foi uma física de origem chinesa que fez grandes contribuições para a física nuclear. Trabalhou no Projeto Manhattan, criando o processo de separação do urânio em urânio-235 e urânio-238 por meio de difusão gasosa e também conduziu o Experimento de Wu. Foi a primeira a ganhar o prêmio Wolf de física em 1978.",
  link: "https://www.atomicheritage.org/sites/default/files/styles/profile_page_image/public/Wu_250.jpg?itok=Ygx6DFzQ",
},

{
  nome: "Rita Levi-Montalcini",
  dicas: ['1. Nasci na Itália, em 1909', '2. Conduzi minhas pesquisas em segredo durante as perseguições facistas e invasões nazistas ',
  '3.  Pesquisei sobre o crescimento das células neurais"',
  '4. Recebi o prêmio Nobel de Medicina e Fisiologia de 1986',
  'Bônus: Meus trabalhos muito auxiliaram na compreenção de variadas condições de saúde .'
  ],
  info: " De origem italiana, Rita foi uma médica neurologista agraciada com o Prêmio Novel de Fisiologia ou Medicina de 1986 pela descoberta de uma substância do corpo que estimula o desenvolvimento de células nervosas, o que ampliou os conhecimentos sobre diversas doenças neurológicas.",
  link: "https://media.gettyimages.com/photos/italian-scientist-rita-levimontalcini-wearing-a-white-gown-sitting-at-picture-id141551270?s=612x612",
},

{
  nome: "Margaret Hamilton",
  dicas: ['1. Sou uma matemática estadunidense', '2. Com apenas 24 começei a trabalhar como programadora para o MIT ',
  '3.  Fui a primeira mulher a integrar o projeto Apollo da NASA',
  '4. Liderou a equipe que desenvolveu o software que levou o homem à lua',
  'Bônus: Partes do código desenvolvido por minha equipe foram utilizadas ainda na "Skylab" e no programa do ônibus espacial'
  ],
  info: " De origem italiana, Rita foi uma médica neurologista agraciada com o Prêmio Novel de Fisiologia ou Medicina de 1986 pela descoberta de uma substância do corpo que estimula o desenvolvimento de células nervosas, o que ampliou os conhecimentos sobre diversas doenças neurológicas.",
  link: "https://img.ibxk.com.br/2015/10/14/14142720950585.jpg?w=1120&h=420&mode=crop&scale=both",
},


];

let coresVetor = ["#3cba1c", "#d1215f", "#851fad", "#4c96d7", "#d39e00"];


// Vetor de objetos que contém as mulheres retratadas no jogo e suas respectivas informações




let informacoesEl;
let proximaEl = document.querySelector('#proxima'); // Botão que faz com que se passe para a próxima "fase", escolhendo outra mulher
let botaoEl = document.querySelector('#botao'); // botão para adicionar nova dica
let pontosAnteriores = localStorage.getItem('pontuacao'); // Pontuação da rodada anterior para ser somada com a da atual
let rodada = localStorage.getItem('contadorDasMulheres'); // Valor do "ContadorMulheres" na rodada anterior, auxilia na passagem de uma mulher à outra
let contadorMulheres = 0;  // É a variável utilizada para acessar as diferentes posições do vetor de objetos que contém as informações que dão base ao jogo
let contadorDicas = 0; // É a variável utilizada para acessar as diferentes posições dos vetores que contêm as dicas sobre cada mulher
let perguntasEl = document.querySelector('#dicas'); // Div onde serão inseridas as dicas
let pontos = 6; // Pontuação
let placar = document.querySelector("#placar"); // Título de quarto nível que retrata a pontuação para o usuário

// Caso não seja a primeira rodada, somar ao contador (=0) o seu valor na rodada anterior, que foi armazenado no localstorage
if(rodada != null){
  contadorMulheres += parseInt(rodada);
}

let alteraCor =0;

// Mostra o usuário sua pontuação
function atualizaPlacar(){
  if(contadorMulheres>0){
    placar.innerHTML = ` ${pontos+parseInt(pontosAnteriores)} Pontos`;
  }else{
    placar.innerHTML = ` ${pontos} Pontos`;
  }
  
}


exibePergunta();

// Função que coloca dicas na tela quando o botão é pressionado
function exibePergunta () {
  
  let perguntasEl = document.querySelector('#dicas');
  let pergunta = document.createElement('h2'); // Funciona criando elementos e adicionando-os ao HTML
  pergunta.innerHTML = `${dicasEl[contadorMulheres].dicas[contadorDicas]}`;
  perguntasEl.appendChild(pergunta);
  pergunta.classList.add('caixas');
  pergunta.style.backgroundColor = `${coresVetor[alteraCor]}`;
  alteraCor++;
  contadorDicas++;
  pontos--;
  atualizaPlacar();
}


botaoEl.addEventListener("click", exibePergunta); // Exibe a dica quando o botão "dica" é apertado

// Esta área do código faz o sorteio das mulheres que vão aparecer em cada posição nas "cartas" ou divs (carts)
let cartsEl = document.querySelectorAll('.cart'); // Seleciona todas as divs da classe "cart", que serão onde ficarão as imagens e nomes das mulheres "opçoes de resposta"
let sorteadosEl = []; // Vetor que armazena quais posições do vetor dicas já foram selecionadas para que uma mulher não apareca mais de uma vez numa mesma rodada

let aj=0; // Variável auxiliar
sorteadosEl.push(contadorMulheres); // Incluí a mulher-resposta no vetor de "já sorteados"
let aux, aux2=0; // Variáveis auxiliares
aux2 = Math.floor(Math.random() * (3-0) ) +0 ; // Sorteia em qual das divs "cart" a imagem e informações da mulher-resposta irão aparecer
let correta; // Mulher resposta da rodada
// Atribui as informações da mulher à div sorteada
correta= cartsEl[aux2];
correta.lastElementChild.innerHTML = `${dicasEl[contadorMulheres].info}`;
correta.firstElementChild.src =  `${dicasEl[contadorMulheres].link}`;
correta.childNodes[3].innerHTML = `${dicasEl[contadorMulheres].nome}`

let num, min=0, max=9;
// Sorteia qual mulher irá preencher cada uma das outras divs não sorteadas
for(let i=0; i<4; i++){
  aux = contadorMulheres;
  if(cartsEl[i] == correta){
    i += 1;
  }
  num = Math.floor(Math.random() * (max - min) ) + min;
  while(aj == 0){
    if(sorteadosEl.indexOf(num) == -1){
      sorteadosEl.push(num);
      aj =1;
    }else{
      num = Math.floor(Math.random() * (max - min) ) + min;
    }
  }

  cartsEl[i].lastElementChild.innerHTML = `${dicasEl[num].info}`;
  cartsEl[i].firstElementChild.src = `${dicasEl[num].link}`;
  cartsEl[i].childNodes[3].innerHTML = `${dicasEl[num].nome}`;
  aj=0;
 
}


//Função que confere se a mulher clicada foi aquela que é a resposta correta
function geraConfere(e){
  let clicado = e.currentTarget; 
  let informacoesEl = document.querySelector("#informacoes"); 
  let mensagem1El = document.querySelector("#msg1"); // Span para dizar se acertou ou errou
  let mensagem2El = document.querySelector("#msg2"); // Span para dizar paragenizar ou pedir que o usuário tente novamente
  let mulherEl = document.querySelector("#nomeia"); // Span para adicionar o nome da mulher que foi clicada, na janela modal
  let mostraPontos = document.querySelector("#mostraPontuacao"); // Campo para apresentar a pontuação na janela modal
  let informacoes2El = document.querySelector("#informacoes2");

  if(clicado == correta ){
      min++; // Para aquela mulher não aparecer denovo
      mensagem1El.innerHTML = "Você acertou! ";
      mulherEl.innerHTML = `${clicado.childNodes[3].innerHTML}`;
      mensagem2El.innerHTML = "PARABÉNS!";
      informacoesEl.innerHTML = ` ${clicado.lastElementChild.innerText}`;
      mostraPontos.innerHTML = `+${pontos} Pontos`;
    
    $('#exampleModalCenter').modal('show');
    contadorMulheres++;

    if(contadorMulheres>1){
      window.localStorage.setItem('pontuacao', pontos+parseInt(pontosAnteriores)); // Salva os pontos como os da rodada atual somados aos das rodadas anteriores
    }else{
      window.localStorage.setItem('pontuacao', pontos); //Salva somente os pontos da rodada pois é a primeira
    }
    window.localStorage.setItem('contadorDasMulheres', contadorMulheres); // salva no localstorage em qual índice se está no vetor "dicasEl"
   
  }else{ // Caso a pessoa tenha errado, exibe uma janela modal com as informações da mulher na qual o usuário clicou
      mensagem1El.innerHTML = "Você errou! ";
      mulherEl.innerHTML = `${clicado.childNodes[3].innerHTML}`;
      informacoesEl.innerHTML = ` ${clicado.lastElementChild.innerText}.`;
      mensagem2El.innerHTML = "Tente novamente!";
      $('#exampleModalCenter').modal('show');
  }
}

  if(contadorMulheres!=9){
    proximaEl.addEventListener("click", proximaMulher); // Atualiza a Página para iniciar a próxima rodada
  }else{
    proximaEl.addEventListener("click", fimDeJogo); // Direciona o jogador para uma página de conclusão do jogo
  }

 function proximaMulher(){
    window.location.reload();
 }

  function fimDeJogo(){
    window.open("venceu.html");
    window.localStorage.setItem('pontuacao', 6);
    window.localStorage.setItem('contadorDasMulheres', 0);

  }
  for(let k=0; k<cartsEl.length; k++){
    cartsEl[k].addEventListener("click", geraConfere); // Adiciona um evento em cada uma das divs "cart" para que se possa conferir a resposta
  }



// “Eu faço parte dos que pensam que a Ciência é belíssima. Um cientista em um laboratório não é apenas um técnico, ele é também uma criança diante de fenômenos naturais que o impressionam como um conto de fada. Não podemos acreditar que todo progresso científico se reduz a mecanismos, máquinas, engrenagens, mesmo que essas máquinas tenham sua própria beleza.”
//link: ["https://267557-830227-raikfcquaxqncofqfm.stackpathdns.com/wp-content/uploads/2019/01/quem-foi-marie-curie-667x400.jpg", "https://timeline.canaltech.com.br/113763.700/mulheres-historicas-carol-shaw-a-primeira-desenvolvedora-de-jogos-eletronicos-75877.jpg", "https://s2.glbimg.com/HpmrkOP7JbbWNQYJjhhswK09mWg=/e.glbimg.com/og/ed/f/original/2018/03/29/katherine_johnson_galileu.jpg", "https://imagens.canaltech.com.br/146005.257839-Ada-Lovelace.jpg"],
