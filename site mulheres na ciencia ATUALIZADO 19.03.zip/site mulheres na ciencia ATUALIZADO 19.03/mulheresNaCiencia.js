let computacaoEl = document.querySelector('#img1');
let divComputacao = document.querySelector('#carComp');

function aparece(){
	divComputacao.classList.toggle('aparecer');
}

computacaoEl.addEventListener("click", aparece);