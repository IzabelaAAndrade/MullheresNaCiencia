Referência: https://citacoes.in/autores/rosalind-franklin/
https://twitter.com/br/status/1102211551111598080 - imagem da Mary Kenneth Keller
https://stories.vassar.edu/2017/170706-legacy-of-grace-hopper.html - imagem grace hopper

Gnipper, P., 2016. Mulheres Históricas: Carol Shaw, A Primeira Desenvolvedora De Jogos Eletrônicos. [online] Canaltech. Available at: <https://canaltech.com.br/internet/mulheres-historicas-carol-shaw-a-primeira-desenvolvedora-de-jogos-eletronicos-75877/> [Accessed 14 March 2020].
https://www.gamespot.com/articles/a-look-back-at-trailblazing-game-developer-carol-s/1100-6457258/ - imagem da Carol Shaw

Hypeness, R., n.d. A História De Margaret Hamilton, A Incrível Mulher Que Foi Pioneira Na Tecnologia E Ajudou A NASA A Aterrissar Na Lua. [online] Hypeness. Available at: <https://www.hypeness.com.br/2017/09/a-historia-de-margaret-hamilton-a-incrivel-mulher-que-foi-pioneira-na-engenharia-e-ajudou-a-nasa-a-aterrissar-na-lua/> [Accessed 20 March 2020].

Época Negócios. 2019. Conheça A História De Margaret Hamilton, A Programadora Que Salvou A Missão À Lua. [online] Available at: <https://epocanegocios.globo.com/Mundo/noticia/2019/07/conheca-historia-de-margaret-hamilton-programadora-que-salvou-missao-lua.html> [Accessed 20 March 2020].

Gnipper, P., 2016. Mulheres Históricas: Irmã Mary Kenneth Keller, Pioneira Na Ciência Da Computação. [online] Canaltech. Available at: <https://canaltech.com.br/internet/mulheres-historicas-irma-mary-kenneth-keller-pioneira-na-ciencia-da-computacao-74111/> [Accessed 20 March 2020].

Gnipper, P., 2016. Mulheres Históricas: Conheça A História De Grace Hopper, A "Vovó Do COBOL". [online] Canaltech. Available at: <https://canaltech.com.br/internet/mulheres-historicas-conheca-a-historia-de-grace-hopper-a-vovo-do-cobol-72559/> [Accessed 20 March 2020].